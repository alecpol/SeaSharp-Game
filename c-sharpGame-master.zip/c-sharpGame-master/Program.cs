﻿using var game = new shooter_game.GameRoot();
game.Run();
